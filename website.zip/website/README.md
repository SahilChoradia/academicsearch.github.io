# AcademicSearch Backend

Backend API for AcademicSearch platform built with Node.js, Express, and MongoDB.

## Features

- User registration and authentication
- JWT-based authentication
- Password hashing with bcrypt
- User profile management
- Password change functionality
- MongoDB database integration

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install